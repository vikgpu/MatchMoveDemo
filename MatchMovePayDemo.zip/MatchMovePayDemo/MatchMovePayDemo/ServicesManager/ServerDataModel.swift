//
//  ServerDataModel.swift
//  SwiftDemo
//
//  Created by Apple on 27/06/18.
//  Copyright © 2018 HP. All rights reserved.
//

import Foundation

//Mark:- Service Status



struct ResponseStatus: Codable {
    let responseCode: String?
    let responseMessage: String?
    
    private  enum CodingKeys: String, CodingKey{
        case responseCode = "ResponseCode";  case responseMessage = "ResponseMessage"
    }
}

//Mark:- Scan History Data

struct HistoryDictionary: Codable{
    let username: String?
    let userID: String?
    let status: String?

    private enum CodingKeys: String, CodingKey{
        case username = "username";  case userID = "user_id";  case status = "status"
    }
}
struct HistoryArrayData: Codable{
    let responseArray: [HistoryDictionary]?
    private  enum CodingKeys: String, CodingKey{
        case responseArray = "ResponseTable"
    }
}



