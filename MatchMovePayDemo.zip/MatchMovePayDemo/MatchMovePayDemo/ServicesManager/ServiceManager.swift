//
//  ServiceManager.swift
//  SwiftDemo
//
//  Created by Apple on 26/06/18.
//  Copyright © 2018 HP. All rights reserved.

import UIKit

class ServiceManager: NSObject {
    
    var  activityIndicator : ActivityIndicator?
    
    func serviceParam( backView: UIView, dict: [String: Any], serviceType: String, serviceHandler:@escaping (Data, Bool)->Void){
        
        activityIndicator = ActivityIndicator(view: backView)
        activityIndicator?.showActivityIndicator()
        
        let headers = [
            "content-type": "application/json",
            "cache-control": "no-cache",
            "postman-token": "74733e86-6fa9-02e4-82b0-de58d0b6b88a"
        ]
        
     //   http://arihantpharmaceuticals.com/job/api/candidate_snd_request
        
        let urlString = "\(baseUrl.DevelopmentUrl)Api/" + serviceType
        print("service URL = \(urlString) \nservice data = \(dict) \n")

        let jsonData = try? JSONSerialization.data(withJSONObject: (dict))

        let request = NSMutableURLRequest(url: NSURL(string: urlString)! as URL,
                                          cachePolicy: .useProtocolCachePolicy,
                                          timeoutInterval: 10.0)
        request.httpMethod = "POST"
        request.allHTTPHeaderFields = headers
        request.httpBody = jsonData

        let session = URLSession.shared
        let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
            
            if (error != nil) {
                self.stopIndicater()
                print(error!)
            } else {
                let httpResponse = response as? HTTPURLResponse
                let statusCode = httpResponse?.statusCode
                self.stopIndicater()

        //        let dataDict: [String: Any] = try! JSONSerialization.jsonObject(with: data!, options: [.allowFragments]) as! [String: Any]
      //          print(dataDict)

                do {
                if statusCode == 200 {
                    
                  //  let codableData =  try  JSONDecoder().decode(ResponseStatus.self, from: data!)
//                    if Int(codableData.responseCode!) == 200 {  //success
//                        print("status code = 200 \n")
//                        serviceHandler(data! , true)
//
//                    }else if Int(codableData.responseCode!)! == 201{  //already register
//                        print("status code = 201 \n")
//
//                    }else { //404
                        print("status code = 404 \n")
                        serviceHandler(data! , false)
                   // }
                }
                 else
                {
                    print("status code = 404 \n")
                    serviceHandler(data! , false)
                }
                }catch let err{
                    print(err)
                }
        }
        })
        
        dataTask.resume()
    }
    
    func stopIndicater(){
        DispatchQueue.main.async {
            self.activityIndicator?.stopActivityIndicator()
        }
    }
    
    
    func postService(){
      /*
        http://gmr.drupalservices.io/travel/index.php/api/user/login
        username_or_mobile:9972398339
        password:12345
        */
        
        let parameters = [
            "username_or_mobile":"9972398339",
            "password":"12345"
            ] as [String : String]
        
        let headers = [
            "content-type": "application/json",
            "cache-control": "no-cache",
        ]
        
        let urlString = "http://gmr.drupalservices.io/travel/index.php/api/user/login"
        print("service URL = \(urlString) \nservice data = \(parameters) \n")
        
        let jsonData = try? JSONSerialization.data(withJSONObject: parameters)
        
        let request = NSMutableURLRequest(url: NSURL(string: urlString)! as URL,
                                          cachePolicy: .useProtocolCachePolicy,
                                          timeoutInterval: 10.0)
        request.httpMethod = "POST"
        request.allHTTPHeaderFields = headers
        request.httpBody = jsonData
        
      
        
        let session = URLSession.shared
        let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
            
            if (error != nil) {
                self.stopIndicater()
                print(error!)
            } else {
                let httpResponse = response as? HTTPURLResponse
                let statusCode = httpResponse?.statusCode
                self.stopIndicater()
                
                let dataDict: [String: Any] = try! JSONSerialization.jsonObject(with: data!, options: [.allowFragments]) as! [String: Any]
                print(dataDict)
                
                    if statusCode == 200 {
                        
                        let httpResponse = response as? HTTPURLResponse
                        let statusCode = httpResponse?.statusCode
                        
                        print(error as Any)
                        print(statusCode as Any)
                    
            
                }            }
        })
        
        dataTask.resume()
        
        
    }
    
func servicegetParam( backView: UIView, serviceType: String, serviceHandler:@escaping (Data, Bool)->Void){
    
    activityIndicator = ActivityIndicator(view: backView)
    activityIndicator?.showActivityIndicator()
    
    let headers = [
        "content-type": "application/json",
        "cache-control": "no-cache",
        "postman-token": "74733e86-6fa9-02e4-82b0-de58d0b6b88a"
    ]
    
  //  http://leadbooks.in/clap/Api/get_offer
    
     let urlString: String = "\(baseUrl.DevelopmentUrl)Api/\(serviceType)"
    
    guard let url = NSURL(string: urlString) else {
        print("Error: cannot create URL")
        return
    }
    
    
 
    
    var urlRequest = URLRequest(url: url as URL)
    
     urlRequest.httpMethod = "GET"
    
    // set up the session
    let config = URLSessionConfiguration.default
    let session = URLSession(configuration: config)
    
    // make the request
    let task = session.dataTask(with: urlRequest, completionHandler: { (data, response, error) in
        // do stuff with response, data & error here
        
        if (error != nil) {
            self.stopIndicater()
            print(error!)
        } else {
            let httpResponse = response as? HTTPURLResponse
            let statusCode = httpResponse?.statusCode
            self.stopIndicater()
            
            do {
                if statusCode == 200 {
                    
                    
                    print("status code = 404 \n")
                    serviceHandler(data! , false)
                    
                }
            }catch let err{
                print(err)
            }
            
        }
        
        
        
    })
    task.resume()
}

}
