//
//  StructureModel.swift
//  SureAssure
//
//  Created by Apple on 11/06/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import Foundation
import UIKit

final class SingletonLocation{
    let islocationServicesEnabled : Bool
    static let locationShareInstance = SingletonLocation()
    private init(){
        islocationServicesEnabled = false
    }
}

struct CheckLocationEnable {

   let  nav: UIViewController
   var  isServiceLocation: Bool

    func  locationDisbleAlert(){
        
        var locationStatus : String?
        if isServiceLocation{
            locationStatus = "Please enable your location in settings."
        }else{
            locationStatus = "Please allows location for this app."
        }
        
        let alertController = UIAlertController (title: "Location", message: locationStatus, preferredStyle: .alert)
        
        let settingsAction = UIAlertAction(title: "Settings", style: .default) { (_) -> Void in
            
            
            if let url = URL(string: "App-Prefs:root=Privacy&path=LOCATION") {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
            
      if !self.isServiceLocation {
        guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
                return
            }
            if UIApplication.shared.canOpenURL(settingsUrl) {
                UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                    print("Settings opened: \(success)")
                })
            }
        }
        else{
           if let url = URL(string: "App-Prefs:root=Privacy&path=LOCATION") {
             UIApplication.shared.open(url, options: [:], completionHandler: nil)
             }
             }
           }
        
        alertController.addAction(settingsAction)
        let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        alertController.addAction(cancelAction)
        nav.present(alertController, animated: true, completion: nil)
        
    }
}


struct ActivityIndicator {
    
    let indicatorBackView = UIView()
    let view: UIView
    let activityIndicator = UIActivityIndicatorView()
    let loadingTextLabel = UILabel()
    let containerView = UIView()

    func showActivityIndicator() {
        
        indicatorBackView.frame = CGRect(x: 0.0, y: 0.0, width: self.view.frame.size.width, height: self.view.frame.size.height)
        indicatorBackView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        view.addSubview(indicatorBackView)
        
        containerView.frame = CGRect(x: 0.0, y: 0.0, width: 150, height: 100)
        containerView.center = view.center
        containerView.backgroundColor = UIColor.init(red: 0.0/255.0, green: 0.0/255.0, blue: 0.0/255.0, alpha: 1.0)
        indicatorBackView.addSubview(containerView)
        containerView.layer.cornerRadius = 5

        activityIndicator.frame = CGRect(x: 0.0, y: 15, width: containerView.frame.size.width, height: 45)
        activityIndicator.hidesWhenStopped = true
        activityIndicator.style = .gray
        activityIndicator.color = .white
        activityIndicator.startAnimating()
        containerView.addSubview(activityIndicator)
        
        loadingTextLabel.textColor = UIColor.white
        loadingTextLabel.text = "Please Wait..."
        loadingTextLabel.font = UIFont.systemFont(ofSize: 15)
        loadingTextLabel.sizeToFit()
        loadingTextLabel.frame = CGRect(x: 0.0, y: activityIndicator.frame.origin.y+activityIndicator.frame.size.height, width: containerView.frame.size.width, height: 20)
        loadingTextLabel.textAlignment = .center
        containerView.addSubview(loadingTextLabel)
        
    }
    
    func stopActivityIndicator() {
        indicatorBackView.removeFromSuperview()
        activityIndicator.stopAnimating()
        activityIndicator.removeFromSuperview()
    }
}






