//
//  Api.swift
//  MatchMovePayDemo
//
//  Created by Mobineers on 18/11/19.
//  Copyright © 2019 Vikas Gupta. All rights reserved.
//

import Foundation
import UIKit

extension UIViewController {
    
    func presentAlertWithTitle(msg:String)
    {
        let alert = UIAlertController(title: "Alert", message: msg, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    func setupToHideKeyboardOnTapOnView()
    {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    @objc func dismissKeyboard()
    {
        view.endEditing(true)
    }
    
    func profileApi(completionHandler:@escaping (Source)->()) {
        var status: String!
        let servicesManager = ServiceManager()
        let userID = (UserDefaults.standard.value(forKey: "userId"))!
        servicesManager.servicegetParam(backView: view, serviceType: "get_user_profile?user_id=\(userID)") { (response, isSuccess) in
            do {
                let dataDict: [String: Any] = try! JSONSerialization.jsonObject(with: response, options: [.allowFragments]) as! [String: Any]
                print(dataDict)
                status = dataDict["success"] as? String
                if (status == "true") {
                    let json1 = try! JSONSerialization.jsonObject(with: response, options: .mutableContainers) as? NSDictionary
                    let sourceDictionary =  json1!["record"] as! NSDictionary
                    Source.init(dictionary: sourceDictionary ,walletDic:json1!["wallet"] as! NSDictionary)
                    completionHandler(Source.init(dictionary: sourceDictionary ,walletDic:json1!["wallet"] as! NSDictionary)!)
                }
                else
                {
                    self.presentAlertWithTitle(msg: (dataDict["message"] as? String)!)
                }
            }catch let err{
                print(err)
            }
            
        }
    }
 
}

