//
//  SourceListViewModel.swift
//  Headlines
//
//  Created by Mohammad Azam on 11/19/17.
//  Copyright © 2017 Mohammad Azam. All rights reserved.
//

import Foundation


class SourceViewModel : NSObject {
    
    var walletAmount :Int!
    var userName :String!
    var mobileNumber :String!
   
    
    init(walletAmount :Int, userName: String, mobileNumber: String) {
        self.walletAmount = walletAmount
        self.userName = userName
        self.mobileNumber = mobileNumber
        
    }
    
    init(source :Source) {
        
        self.walletAmount = source.walletAmount
        self.userName = source.userName
        self.mobileNumber = source.mobileNumber
       
    }
}



