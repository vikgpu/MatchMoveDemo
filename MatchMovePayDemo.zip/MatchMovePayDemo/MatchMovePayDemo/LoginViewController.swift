//
//  LoginViewController.swift
//  MatchMovePayDemo
//
//  Created by Vikas Gupta on 17/11/19.
//  Copyright © 2019 Vikas Gupta. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController,UITextFieldDelegate {

    
   // @IBOutlet weak var otpTf: UITextField!
    @IBOutlet weak var otpTf: UITextField!
    @IBOutlet weak var mobileTF: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var loginBgView: UIView!
    var checkString = String()
    var userID = String()
    override func viewDidLoad() {
        super.viewDidLoad()

        mobileTF.delegate = self
        otpTf.delegate = self
        loginBgView.dropShadow()
        loginButton.layer.cornerRadius = 5.0
        loginButton.clipsToBounds = true
        
        if #available(iOS 12.0, *) {
            otpTf.textContentType = UITextContentType.oneTimeCode;
        }
        
       checkString = "LoginwithMobile"
        
    }
    
    @IBAction func loginButtonAction(_ sender: Any) {
      
        if(checkString == "LoginwithMobile"){
            if(mobileTF?.text == "")
            {
                presentAlertWithTitle(msg:"Please Enter Mobile Number")
            }
            else{
                
               genrateOtpApi()
            }
        }else{
            
            if(otpTf?.text == "")
            {
                presentAlertWithTitle(msg:"Please Enter OTP")
            }
            else{
                
                verifyOTPApi()
            }
            
        }
        
        
    }
    
    func genrateOtpApi()
    {

        // https://leadbooks.in/clap/Api/login?mobile=8409243390
        var status: String!
        var reqid:String!
        let servicesManager = ServiceManager()
        
        //let urlString: String = "http://arihantpharmaceuticals.com/job/api/\(serviceType)?email=\((usernameStr)!)&password=\((pass)!)&user_type=\((dict["user_type"])!)&device_token=12345"
        
        // https://leadbooks.in/clap/Api/get_products_by_subcat?sub_category_id=3
        
        servicesManager.servicegetParam(backView: view, serviceType: "login?mobile=\(mobileTF.text!)") { (response, isSuccess) in
            do {
                
                let dataDict: [String: Any] = try! JSONSerialization.jsonObject(with: response, options: [.allowFragments]) as! [String: Any]
                print(dataDict)
                
                status = dataDict["success"] as? String
                
                
                
                DispatchQueue.main.async {
                    
                    DispatchQueue.main.async {
                        
                        if (status == "true") {
                            
                            
                            self.mobileTF.isHidden = true
                            self.otpTf.isHidden = false
                            self.loginButton.setTitle("LOGIN", for: .normal)
                            self.checkString = "Loginwithotp"
                            
                            if let id = dataDict["user_id"]  as? NSNumber {
                                
                                self.userID = "\(dataDict["user_id"] as! NSNumber )"
                                
                            }else{
                                self.userID = (dataDict["user_id"] as? String)!
                            }
                            
                        }
                        else
                        {
                            self.presentAlertWithTitle(msg: (dataDict["message"] as? String)!)
                        }
                        
                        
                        
                    }
                    
                    
                }
                
                
            }catch let err{
                print(err)
            }
            
        }
    }
    
    func verifyOTPApi()
    {
       
        var status: String!
        var reqid:String!
        let servicesManager = ServiceManager()
        
        let devicesToken = UserDefaults.standard.value(forKey: "devicesToken") as! String
        
        
        //let urlString: String = "http://arihantpharmaceuticals.com/job/api/\(serviceType)?email=\((usernameStr)!)&password=\((pass)!)&user_type=\((dict["user_type"])!)&device_token=12345"
        
        // https://leadbooks.in/clap/Api/get_products_by_subcat?sub_category_id=3
        
        servicesManager.servicegetParam(backView: view, serviceType: "confirm_opt?otp=\(otpTf.text!)&user_id=\(self.userID)&device_token=\(devicesToken)") { (response, isSuccess) in
            do {
                
                let dataDict: [String: Any] = try! JSONSerialization.jsonObject(with: response, options: [.allowFragments]) as! [String: Any]
                print(dataDict)
                
                status = dataDict["success"] as? String
                
                
                
                DispatchQueue.main.async {
                    
                    DispatchQueue.main.async {
                        
                        
                        if (status == "true") {
                            
                            UserDefaults.standard.setValue("loginfirstTime", forKey: "loginfirstTime")
                            UserDefaults.standard.setValue(self.userID, forKey: "userId")
                            
                        }
                        else
                        {
                            self.presentAlertWithTitle(msg: (dataDict["message"] as? String)!)
                        }
                        
                        
                        
                    }
                    
                    
                }
                
                
            }catch let err{
                print(err)
            }
            
        }
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
        
    }
   

}
