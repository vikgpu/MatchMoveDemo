//
//  HomeViewController.swift
//  MatchMovePayDemo
//
//  Created by Vikas Gupta on 17/11/19.
//  Copyright © 2019 Vikas Gupta. All rights reserved.
//

import UIKit



class HomeViewController: UIViewController {

    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var transactionView: UIView!
    @IBOutlet weak var addCardButton: UIButton!
    @IBOutlet weak var cardView: UIView!
    @IBOutlet weak var amountLbl: UILabel!
    @IBOutlet weak var walletView: UIView!
    @IBOutlet weak var navigationView: UIView!
    @IBOutlet weak var nameLbl: UILabel!
    var profileData:Source!
    override func viewDidLoad() {
        super.viewDidLoad()
    navigationView.addBottomRoundedEdge(desiredCurve: 2.0)
        
         walletView.dropShadow()
         cardView.dropShadow()
         transactionView.dropShadow()
        
        addCardButton.layer.cornerRadius = 5.0
        
        let attributedWithTextColor1: NSAttributedString = amountLbl.text!.attributedStringWithColor(["₹"], color: UIColor.gray)
        amountLbl.attributedText = attributedWithTextColor1
        
        
            let tap: UITapGestureRecognizer = UITapGestureRecognizer(
                target: self,
                action: #selector(HomeViewController.profileImageViewClick))
            tap.cancelsTouchesInView = false
            profileImageView.isUserInteractionEnabled = true
            profileImageView.addGestureRecognizer(tap)
          self.profileApi { [unowned self] sources in
            self.profileData = sources
           DispatchQueue.main.async {
              self.amountLbl.text = "₹ " + "\(self.profileData.walletAmount!)"
            
            if(self.profileData.userName! != ""){
                self.nameLbl.text = "Hi " + "\(self.profileData.userName!)"
            }
           }
        }
        
    }

    @IBAction func seeAllButtonAction(_ sender: Any) {
        
        let mapViewControllerObj = self.storyboard?.instantiateViewController(withIdentifier: "TabBarViewController") as? TabBarViewController
        mapViewControllerObj?.selectedViewController = mapViewControllerObj?.viewControllers![3]
        self.present(mapViewControllerObj!, animated: false, completion: nil)
        
    }
    
    @objc func profileImageViewClick()
    {
        let mapViewControllerObj = storyboard?.instantiateViewController(withIdentifier: "ProfileViewController") as? ProfileViewController
        mapViewControllerObj?.profileData = self.profileData
        self.present(mapViewControllerObj!, animated: false, completion: nil)
    }
    

}
