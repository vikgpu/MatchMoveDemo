//
//  SendViewController.swift
//  MatchMovePayDemo
//
//  Created by Vikas Gupta on 17/11/19.
//  Copyright © 2019 Vikas Gupta. All rights reserved.
//

import UIKit

class SendViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var walletAmountLbl: UILabel!
    @IBOutlet weak var walletView: UIView!
    @IBOutlet weak var navigationView: UIView!
    var profileData:Source!
    override func viewDidLoad() {
        super.viewDidLoad()

       self.setupToHideKeyboardOnTapOnView()
       walletView.dropShadow()
       navigationView.addBottomRoundedEdge(desiredCurve: 2.0)
        
        self.profileApi { [unowned self] sources in
            self.profileData = sources
            DispatchQueue.main.async {
                self.walletAmountLbl.text = "₹ " + "\(self.profileData.walletAmount!)"
                
            }
        }
        
    }
    

    func textField(_ textField: UITextField, shouldChangeCharactersIn range:NSRange, replacementString string: String) -> Bool {
        
        if (range.location >= 10){
            return false
        }
        
        return true
    }

}
