//
//  ProfileViewController.swift
//  MatchMovePayDemo
//
//  Created by Mobineers on 18/11/19.
//  Copyright © 2019 Vikas Gupta. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {

    @IBOutlet weak var mainScrollView: UIScrollView!
    @IBOutlet weak var moreView: UIView!
    @IBOutlet weak var profileView: UIView!
    @IBOutlet weak var navigationVIew: UIView!
    @IBOutlet weak var mobileNumber: UILabel!
    @IBOutlet weak var userNameLbl: UILabel!
    var profileData:Source!
    override func viewDidLoad() {
        super.viewDidLoad()

        navigationVIew.addBottomRoundedEdge(desiredCurve: 2.0)
        
        profileView.dropShadow()
        moreView.dropShadow()
        
        if(self.profileData.userName! != ""){
            self.userNameLbl.text = "\(self.profileData.userName!)"
        }
        
        self.mobileNumber.text = "\(self.profileData.mobileNumber!)"
        
       mainScrollView.contentSize = CGSize(width: 0, height: moreView.frame.origin.y+moreView.frame.size.height)
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func logOutButtonAction(_ sender: Any) {
        
        UserDefaults.standard.removeObject(forKey: "loginfirstTime")
        UserDefaults.standard.removeObject(forKey: "userId")
        let mapViewControllerObj = storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController
        self.present(mapViewControllerObj!, animated: false, completion: nil)
    }
}
