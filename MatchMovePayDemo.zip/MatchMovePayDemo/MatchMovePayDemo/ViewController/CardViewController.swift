//
//  CardViewController.swift
//  MatchMovePayDemo
//
//  Created by Vikas Gupta on 17/11/19.
//  Copyright © 2019 Vikas Gupta. All rights reserved.
//

import UIKit

class CardViewController: UIViewController {

    @IBOutlet weak var addCardButton: UIButton!
    @IBOutlet weak var cardView: UIView!
    @IBOutlet weak var navigationView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()

        navigationView.addBottomRoundedEdge(desiredCurve: 2.0)
         cardView.dropShadow()
        

        let segementView = UIView(frame: CGRect(x: 0, y: 100, width: self.view.frame.size.width, height: 50))
    //    segementView.backgroundColor = UIColor.black
        navigationView.addSubview(segementView)
        
         let items = ["VIRTUAL CARDS" , "PHYSICAL CARDS"]
        let segmentedControl = UISegmentedControl(items : items)
        segmentedControl.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 48)
        segmentedControl.selectedSegmentIndex = 1
        segmentedControl.addTarget(self, action: #selector(CardViewController.indexChanged(_:)), for: .valueChanged)
        segmentedControl.removeBorders()
        segementView.addSubview(segmentedControl)
        let attributes = [ NSAttributedString.Key.foregroundColor : UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 0.6),
                           NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 15.0)];
        let attributesSelected = [ NSAttributedString.Key.foregroundColor : UIColor.white,
                                   NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 15.0)];
        UISegmentedControl.appearance().setTitleTextAttributes(attributesSelected, for: .selected)
        UISegmentedControl.appearance().setTitleTextAttributes(attributes, for: .normal)
        
        
        let lineview = UIView(frame: CGRect(x: self.view.frame.size.width/2, y: segmentedControl.frame.origin.y+segmentedControl.frame.size.height, width: self.view.frame.size.width/2, height: 2))
        lineview.backgroundColor = UIColor.white
        lineview.tag = 600
        segementView.addSubview(lineview)
        
         addCardButton.layer.cornerRadius = 5.0
    }
    
    @objc func indexChanged(_ sender: UISegmentedControl) {
        
        let lineView = view.viewWithTag(600) as! UIView
        switch sender.selectedSegmentIndex{
        case 0:

            lineView.frame = CGRect(x: 0, y: 48, width: self.view.frame.size.width/2, height: 2)

        case 1:
            lineView.frame = CGRect(x: self.view.frame.size.width/2, y: 48, width: self.view.frame.size.width/2, height: 2)
 
        default:
            break
        }
        
    }
    

    

}
