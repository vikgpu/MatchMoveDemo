//
//  Source.swift
//  Headlines
//
//  Created by Mohammad Azam on 11/19/17.
//  Copyright © 2017 Mohammad Azam. All rights reserved.
//

import Foundation

class Source : NSObject{
    
    var walletAmount :Int!
    var userName :String!
    var mobileNumber :String!
    
    init?(dictionary :NSDictionary , walletDic:NSDictionary) {
        
        guard let userName = dictionary["name"] as? String,
        let mobileNumber = dictionary["mobile"] as? String,
        let walletAmount = walletDic["amount"] as? Int else {
                return nil
        }

        self.userName = userName
        self.walletAmount = walletAmount
        self.mobileNumber = mobileNumber

}

    func validMobileNumber() -> Bool{
        return mobileNumber.count < 11
    }

    init(viewModel :SourceViewModel) {

        self.walletAmount = viewModel.walletAmount
        self.userName = viewModel.userName
        self.mobileNumber = viewModel.mobileNumber

    }
    
}


