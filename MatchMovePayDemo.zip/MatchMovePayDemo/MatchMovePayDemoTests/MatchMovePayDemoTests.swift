//
//  MatchMovePayDemoTests.swift
//  MatchMovePayDemoTests
//
//  Created by Vikas Gupta on 17/11/19.
//  Copyright © 2019 Vikas Gupta. All rights reserved.
//

import Foundation
import XCTest
@testable import MatchMovePayDemo

class MatchMovePayDemoTests: XCTestCase {

    
    func testMobileNumberInValid(){
        
        let source = Source(dictionary: ["name":"vikas","mobile":"12345678901"], walletDic: ["amount":0])
        XCTAssertFalse(source!.validMobileNumber())
    }
    
    func testMobileNumberValid(){
        
        let source = Source(dictionary: ["name":"vikas","mobile":"1234567890"], walletDic: ["amount":0])
        XCTAssertTrue(source!.validMobileNumber())
        
    }
    
    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
